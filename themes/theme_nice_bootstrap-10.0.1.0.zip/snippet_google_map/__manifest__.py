{
    'name':'Google Map Snippet',
    'description':'Google Map Snippet',
    'category': 'Website',
    'version':'1.1',
    'author':'Odoo S.A.',
    'data': [
        'views/assets.xml',
        'views/s_google_map.xml',
    ],
    'depends': ['theme_common'],
}
