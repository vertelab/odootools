Changelog
=========

Credits
=======
Authors
~~~~~~~
* Vertel AB
Contributors
~~~~~~~~~~~~
* <Fill Your Name Here>
Maintainers
~~~~~~~~~~~
This module is maintained by the Vertel AB.

You can find this moudle at: <URL-TO-ODOO-APPS>.
This moudle is maintained at: <URL-TO-PUBLIC-GIT>.
